class ResImages {
  static const String _path = 'assets/images/';
  static const String logoLight = '${_path}logo-light.png';
}
