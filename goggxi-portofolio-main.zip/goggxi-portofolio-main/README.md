# Goggxi Portofolio

## Terminal
```bash
# dart activate script local
dart pub global activate flutter_scripts
# run script
flutter_scripts run
```
